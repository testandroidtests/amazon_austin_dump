#!/usr/bin/python

VERSION = '0.1'

"""
This tool analyzes a TRAPZ event log using a state machine "scenario"

./scenario.py --help for usage
"""

import sys
from trapztool import *
from scenarios import *

try:
    import numpy as np
except ImportError:
    sys.stderr.write("This script requires SciPy package\n")
    sys.stderr.write("Ubuntu: sudo apt-get install python-scipy\n")
    sys.stderr.write("Other platforms: see http://www.scipy.org/Installing_SciPy\n")
    sys.exit(1)

class TrapzScenario(TrapzXmlVcd):
    """This class runs the TRAPZ event log through a state machine that detects
    a given scenario and collects elapsed time statistics on it. Since a
    pipelined scenario may be occuring several times at once in different
    states, we maintain a pool of state machine objects. There is always one
    state machine in the pool that is in the START state to catch the beginning
    of a new scenario instance. The other scenarios are all in intermediate
    states, and are removed from the pool when they finish or report an
    error.

    This class inherits from TrapzXmlVcd in order to be able to write a VCD
    file.  In the non-VCD case however, it is effectively inheriting from
    TrapzXmlValidator which is a parent class of TrapzXmlVcd. This is used
    to parse the XML events and component names."""

    def __init__(self, stateMachine, vcdFile=None, vcdLongStateName=False):
        if vcdFile:
            vcdWriter = VcdWriter(vcdFile)
            vcdWriter.SetTimescale('ns')
            TrapzXmlVcd.__init__(self, vcdWriter)
            self.writeVcd = True
            self.vcdLongStateName = vcdLongStateName
        else:
            TrapzXmlValidator.__init__(self)
            self.writeVcd = False
        self.stateMachine = stateMachine
        self.runningMachines = set()
        self.finishedMachines = []
        self.elapsed = {}
        self.AddNewMachine()

    def AddNewMachine(self):
        "Add a new state machine to the pool."
        self.newMachine = self.stateMachine()
        self.runningMachines.add(self.newMachine)

    def Run(self, ignorefl):
        for e in self.events:
            self.ProcessEvent(e)
        if self.writeVcd:
            self.AddAllEventsToVcd()
        if ignorefl and len(self.finishedMachines) > 2:
            del self.finishedMachines[0]
            del self.finishedMachines[len(self.finishedMachines) - 1]
        if len(self.finishedMachines):
            for sm in self.finishedMachines:
                for (transitionName, elapsed) in sm.elapsed.items():
                    self.elapsed.setdefault(transitionName, []).append(elapsed)

    def ProcessEvent(self, event):
        matchCount = 0
        # list() ensures that we aren't mutating the object that we are
        # iterating over
        for sm in list(self.runningMachines):
            result = sm.ProcessEvent(event, self)
            if result:
                if result == StateMachine.ERROR:
                    self.runningMachines.remove(sm)
                else:
                    matchCount += 1

                if result == StateMachine.FINISHED:
                    # update overall scenario elapsed times to include results
                    # from this state machine
                    self.runningMachines.remove(sm)
                    self.finishedMachines.append(sm)

                if sm is self.newMachine:
                    # The new state machine isn't new anymore; make another new
                    # state machine and add it to the pool.
                    self.AddNewMachine()

        if matchCount > 1:
            sys.stderr.write("WARNING: Event %s used by %d state machine instances\n" \
                                 % (event.State(self), matchCount))


    def AddAllEventsToVcd(self):
        TrapzXmlVcd.AddAllEventsToVcd(self)

        if not len(self.finishedMachines):
            return

        # add component for our state machine
        component = ElementTree.Element('component')
        component.set('name', self.stateMachine.NAME)
        component.set('inUse', '1')
        self.rootComponent.append(component)

        for (i, sm) in enumerate(self.finishedMachines):
            # import pdb; pdb.set_trace()
            signalName = sm.NAME + str(i)
            trace = ElementTree.Element('trace')
            trace.set('name', signalName)
            trace.set('vcdId', signalName)
            trace.set('inUse', '1')
            component.append(trace)

            for (timestamp, state, value) in sm.history:
                if self.vcdLongStateName:
                    self.vcdWriter.Event(timestamp, signalName, state)
                else:
                    self.vcdWriter.Event(timestamp, signalName, value)

        interval = self.stateMachine.COUNT_INTERVAL
        if interval:
            signalName = '%sCount_%d_sec' % (sm.NAME, interval)
            trace = ElementTree.Element('trace')
            trace.set('name', signalName)
            trace.set('vcdId', signalName)
            trace.set('inUse', '1')
            component.append(trace)

            # Timestamps for every state machine that enters finished state
            finishTimestamps = [sm.history[-1][0] for sm in self.finishedMachines]
            # We maintain this fifo with a list of state machines that finished in the last
            # COUNT_INTERVAL seconds.
            timestampFifo = []
            for timestamp in finishTimestamps:
                # Generate events as stale timestamps drop out of fifo.
                while (len(timestampFifo) and
                       (timestampFifo[0] + interval < timestamp)):
                    self.vcdWriter.Event(timestampFifo.pop(0) + interval, signalName, str(len(timestampFifo)))
                # Generate event as this timestamp is added to fifo.
                timestampFifo.append(timestamp)
                self.vcdWriter.Event(timestamp, signalName, str(len(timestampFifo)))
            # Generate events as all remaining timestamp drop out of fifo.
            while len(timestampFifo):
                self.vcdWriter.Event(timestampFifo.pop(0) + interval, signalName, str(len(timestampFifo)))

    def Export(self):
        if not len(self.finishedMachines):
            print "The scenario never matched so there is no data to export."
            return
        # assume order of 1st finished machine is valid
        headerline = ""
        for transition in self.finishedMachines[0].order:
            headerline += transition.replace('__', ' -> ') + ", "
        print headerline[:-2]
        for sm in self.finishedMachines:
            dataline = ""
            for transition in self.finishedMachines[0].order:
                dataline += str(sm.elapsed.get(transition) / 1000000.0) + ", "
            print dataline[:-2]

    def Statistics(self):
        if not len(self.finishedMachines):
            print "The scenario never matched so there is no data to report."
            return
        # assume order of 1st finished machine is valid
        print "%6s%12s%12s%12s%12s %20s" % ('COUNT', 'MEAN', 'STDDEV', 'MIN', 'MAX', 'EVENTS')
        print "%6s%12s%12s%12s%12s %20s" % ('=====', '========', '========', '========', '========', '====================')
        for transition in self.finishedMachines[0].order:
            elapsedArray = np.array(self.elapsed[transition], dtype=np.float64)
            elapsedArray /= 1000000
            print "%6d %9.3fms %9.3fms %9.3fms %9.3fms [%s]" % \
                ((len(elapsedArray), np.mean(elapsedArray), np.std(elapsedArray),
                  np.min(elapsedArray), np.max(elapsedArray), transition.replace('__', ' -> ')))

    def Histograms(self):

        if not len(self.finishedMachines):
            print "The scenario never matched so there is no data to report."
            return

        try:
            import matplotlib.pyplot as plt
        except ImportError:
            sys.stderr.write("This script requires matplotlib package\n")
            sys.stderr.write("Ubuntu: sudo apt-get install python-matplotlib\n")
            sys.stderr.write("Other platforms: see http://matplotlib.sourceforge.net/\n")
            sys.exit(1)

        fig = plt.figure()

        for transition in self.finishedMachines[0].order:
            elapsedArray = np.array(self.elapsed[transition], dtype=np.float64)
            elapsedArray *= 1000

            sub = fig.add_subplot(1,1,1)
            #(hist,bins) = np.histogram(elapsedArray, bins=50)
            #center=(bins[:-1]+bins[1:])/2
            #width=0.7*(bins[1]-bins[0])
            #sub.bar(center,hist,align='center',width=width)
            sub.hist(elapsedArray, 50)
            sub.set_xlabel('milliseconds')
            sub.set_ylabel('count')
            sub.set_title(transition.replace('__', ' -> '))
            print "Showing %s, click in figure to continue" % transition.replace('__', ' -> ')
            fig.canvas.draw()
            fig.ginput()
            fig.clear()
            # plt.show()

        # fig.show()


def ListCommand(args):
    StateMachine.PrintSubclasses(StateMachine)

def ExportCommand(args):
    scenario = TrapzScenario(StateMachine.LookupSubclass(StateMachine, args.scenario))
    scenario.Parse(args.trapzfile)
    scenario.Run(args.ignore_first_last)
    scenario.Export()

def StatCommand(args):
    scenario = TrapzScenario(StateMachine.LookupSubclass(StateMachine, args.scenario))
    scenario.Parse(args.trapzfile)
    scenario.Run(args.ignore_first_last)
    scenario.Statistics()

def HistCommand(args):
    scenario = TrapzScenario(StateMachine.LookupSubclass(StateMachine, args.scenario))
    scenario.Parse(args.trapzfile)
    scenario.Run(args.ignore_first_last)
    scenario.Histograms()

def VcdCommand(args):
    scenario = TrapzScenario(StateMachine.LookupSubclass(StateMachine, args.scenario),
                             args.vcdfile, args.long_names)
    scenario.Parse(args.trapzfile)
    scenario.Run(args.ignore_first_last)
    scenario.WriteVcd()


if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser(description='TRAPZ Scenario Runner')
    parser.add_argument('-v', '--version', action='version', version='%%(prog)s %s' % VERSION)

    subparsers = parser.add_subparsers(title='Commands')

    # parser options for listing scenarios
    subP = subparsers.add_parser('list', help='List available scenarios')
    subP.set_defaults(func=ListCommand)

    # parser options for exporting state
    subP = subparsers.add_parser('export', help='Export states')
    subP.add_argument('trapzfile', nargs='?', type=argparse.FileType('r'),
                            default=sys.stdin, help='filename of TRAPZ XML trace file')
    subP.add_argument('-s', '--scenario', required=True)
    subP.add_argument('--ignore-first-last', action='store_const', const=1, default=0, help='ignore first and last data points', required=False)
    subP.set_defaults(func=ExportCommand)

    # parser options for generating statistics
    subP = subparsers.add_parser('stat', help='Produce statistics for elapsed time in states')
    subP.add_argument('trapzfile', nargs='?', type=argparse.FileType('r'),
                            default=sys.stdin, help='filename of TRAPZ XML trace file')
    subP.add_argument('-s', '--scenario', required=True)
    subP.add_argument('--ignore-first-last', action='store_const', const=1, default=0, help='ignore first and last data points', required=False)
    subP.set_defaults(func=StatCommand)

    # parser options for generating histogram
    subP = subparsers.add_parser('hist', help='Display elapsed times in states as histograms')
    subP.add_argument('trapzfile', nargs='?', type=argparse.FileType('r'),
                            default=sys.stdin, help='filename of TRAPZ XML trace file')
    subP.add_argument('-s', '--scenario', required=True)
    subP.add_argument('--ignore-first-last', action='store_const', const=1, default=0, help='ignore first and last data points', required=False)
    subP.set_defaults(func=HistCommand)

    # parser options for generating VCD file
    subP = subparsers.add_parser('vcd', help='Produce VCD file with scenario traces')
    subP.add_argument('trapzfile', nargs='?', type=argparse.FileType('r'),
                            default=sys.stdin, help='filename of TRAPZ XML trace file')
    subP.add_argument('vcdfile', nargs='?', type=argparse.FileType('w'),
                           default=sys.stdout, help='filename for generated VCD file')
    subP.add_argument('-s', '--scenario', required=True)
    subP.add_argument('--long-names', action='store_true', default=False,
                            help='use long state names in signal trace')
    subP.add_argument('--ignore-first-last', action='store_const', const=1, default=0, help='ignore first and last data points', required=False)
    subP.set_defaults(func=VcdCommand)

    # parse the command line
    args = parser.parse_args()

    # invoke the subcommand function
    args.func(args)
