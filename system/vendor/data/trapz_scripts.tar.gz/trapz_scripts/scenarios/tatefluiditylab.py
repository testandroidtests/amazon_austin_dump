from statemachine import StateMachine

class TateFluidityLabStateMachine(StateMachine):
    """See StateMachine base class in statemachine.py for documentation. It
    will make everything clear (or at least clearer)."""

    NAME = "TateFluidityLab"
    DESCRIPTION = "Drawing states for FluidityLab application on Tate platform"


    def START__Touch_CypressTouchEvent(self,event):
        "A"
        self.hdwx = event.e1
        self.hdwy = event.e2
        return True

    def Touch_CypressTouchEvent__Touch_kernel_evdev(self,event):
        "B"
        return self.hdwy == event.e2

    def Touch_kernel_evdev__Input_GetInputEvent(self,event):
        "C"
        return self.hdwy == event.e2

    def Input_GetInputEvent__Input_PrepareDispatchMotion(self,event):
        "D"
        self.x = event.e1
        self.y = event.e2
        return True

    def Input_PrepareDispatchMotion__Input_InputQueueJni(self,event):
        "E"
        return self.x == event.e1 and self.y == event.e2

    def Input_InputQueueJni__InputQueueJava_MotionEvent(self,event):
        "F"
        return self.x == event.e1 and self.y == event.e2

    def InputQueueJava_MotionEvent__ViewSubSystem_TouchEvent(self,event):
        "G"
        return self.x == event.e1 and self.y == event.e2

    def ViewSubSystem_TouchEvent__SurfaceFlinger_SetupHWCTouch(self,event):
        "H"
        return self.x == event.e1 and self.y == event.e2

    def SurfaceFlinger_SetupHWCTouch__HardwareComposer_HwcPrepare(self,event):
        "I"
        self.syncid = event.e1
        return True

    def HardwareComposer_HwcPrepare__DssDriver_DssCompGrallocQueueSync(self,event):
        "J"
        self.grallocaddr = event.e2
        return self.syncid == event.e1

    def DssDriver_DssCompGrallocQueueSync__DssDriver_DssCompGrallocCallback(self,event):
        "K"
        return self.grallocaddr == event.e1

    def DssDriver_DssCompGrallocCallback__DssDriver_DssIrqHandler(self,event):
        "L"
        return StateMachine.FINISHED

