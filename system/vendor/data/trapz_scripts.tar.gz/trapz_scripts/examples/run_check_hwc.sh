#!/bin/bash
# run on workstation to capture logs and run the check_hwc.py script

trapzdir="${TRAPZ_DIR:?"export this var for directory with trapztool.py"}"
trapztool="$trapzdir/trapztool.py"
original_pythonpath=$PYTHONPATH
export PYTHONPATH="$trapzdir:$PYTHONPATH"

tmpfile="${TRAPZ_LOG_DIR:-/tmp}/trapz-check_hwc.xml"
vcd_file="${TRAPZ_LOG_DIR:-/tmp}/trapz-check_hwc.vcd"

# enable the trace we want to capture
$trapztool filter HardwareComposer info

# clear the trapz buffers
read -p "press enter to start trapz log capture: "
adb shell trapz -c
echo CAPTURING......

read -p "press enter to stop trapz log capture: "

adb shell trapz -x > $tmpfile

"$(dirname "$0")/check_hwc.py" $tmpfile

$trapztool vcd --no-tids $tmpfile $vcd_file

# restore
export PYTHONPATH="$original_pythonpath"
