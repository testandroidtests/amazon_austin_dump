#!/usr/bin/python

VERSION = '0.1'

"""
Simple script to see whether the graphics pipeline is using
the prefered composition technique (HWC or DSS Composition) versus
the slower GPU composition (SGX).
"""

if __name__ == "__main__":

    from trapztool import SimpleTrapz
    import argparse

    description = "Simple script to count HWC frames"
    parser = argparse.ArgumentParser(description=description,
    formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('xmlfile', help='filename of XML-format TRAPZ log dump')
    args = parser.parse_args()
    trapzfile = args.xmlfile

    strapz = SimpleTrapz(trapzfile)

    frame_events = strapz.filterEvents("HardwareComposer","HWCFrameUpdate")

    # for hwc, event.e1 == 1, else 0
    hwc_count = reduce( lambda count, event: count + event.e1, frame_events, 0 )

    print "hwc_frame_count={0} total_frame_count={1}".format( hwc_count, len(frame_events) )

