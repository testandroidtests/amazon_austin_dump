#!/bin/bash
# create a zip file of all interesting trapz source, for sharing and review

outfile="/tmp/trapz_src.tar.gz"

pushd ${ANDROID_BUILD_TOP:?"must be set in the environment"}/.. >/dev/null
echo MAKING TRAPZ ARCHIVE $outfile FROM $(pwd)

scripts="labscripts/trapz"
trapz_h="kernel/android-3.0/include/linux/trapz.h mydroid/bionic/libc/kernel/common/linux/trapz.h"
trapz_c="kernel/android-3.0/drivers/staging/trapz/trapz.c"
profile_svc="mydroid/frameworks/base/services/java/com/lab126/services/Profile*.java "
trapz_java="mydroid/frameworks/base/core/java/com/amazon/profile mydroid/frameworks/base/core/jni/com_amazon_profile_Trapz.cpp"
trapz_java_service="mydroid/frameworks/base/core/java/amazon/profile"
trapz_cmd="mydroid/system/extras/trapz"
trapz_native="mydroid/frameworks/base/include/trapz"
trapz_native_lib="mydroid/frameworks/base/libs/trapz"

# EXCLUDES
script_excludes="labscripts/trapz/out*"
script_excludes_old="labscripts/trapz/include*"
argparse_exclude="labscripts/trapz/argparse*"

all="$scripts $trapz_h $trapz_c $profile_svc $trapz_java $trapz_cmd $trapz_native $trapz_java_service $trapz_native_lib"

tar cvzf $outfile $all --exclude="$script_excludes" --exclude="$script_excludes_old" --exclude="$argparse_exclude" --exclude "*/\.*"

popd >/dev/null
